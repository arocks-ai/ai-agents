from datetime import datetime

class LLMClient:
    def summarize_readiness(self, work_items, pipelines, security):
        score = 100
        blockers = []

        for wi in work_items:
            if wi.get("blocking", False) or "blocker" in [t.lower() for t in wi.get("tags", [])]:
                score -= 30
                blockers.append({"id": wi["id"], "title": wi["title"], "why": "Blocking item", "evidence_url": wi.get("url")})
            elif wi.get("state","").lower() != "closed":
                score -= 5

        for p in pipelines:
            for run in p.get("last_runs", []):
                if run.get("status") != "succeeded":
                    score -= 20
                    blockers.append({"id": f"pipeline:{p['pipeline_id']}-run:{run['run_id']}","title": f"Pipeline {p['name']} failed","why": f"Failed stage: {run.get('failed_stage')}","evidence_url": f"{p['name']}/runs/{run['run_id']}"})

        if security.get("critical",0) > 0:
            score -= 25
            for d in security.get("details", []):
                blockers.append({"id": d.get("id"), "title": f"Security: {d.get('component')}", "why": f"Severity: {d.get('severity')}", "evidence_url": f"security/{d.get('id')}"})

        score = max(0, min(100, score))
        go_no_go = "GO" if score >= 70 and not blockers else "NO-GO"

        summary = f"Score {score}. Found {len(blockers)} blockers. Criticals: {security.get('critical',0)}."

        recs = []
        if blockers:
            recs.append("Fix blocking issues before release.")
        if any(run.get("status")!="succeeded" for p in pipelines for run in p.get("last_runs", [])):
            recs.append("Rerun failed pipelines.")
        if security.get("critical",0)>0:
            recs.append("Patch critical vulnerabilities.")

        rollback = "Rollback to previous stable build." if score < 40 else None

        return {
            "readiness_score": score,
            "go_no_go": go_no_go,
            "summary": summary,
            "blockers": blockers[:5],
            "recommended_actions": recs,
            "suggested_rollback_plan": rollback,
            "last_fetched": { "timestamp": datetime.utcnow().isoformat()+"Z" }
        }
