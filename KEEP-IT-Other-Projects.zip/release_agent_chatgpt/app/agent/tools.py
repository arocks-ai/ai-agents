import requests

class ADOClient:
    def __init__(self, base_url="http://127.0.0.1:8000"):
        self.base = base_url.rstrip("/")

    def query_work_items(self, project=None, tag=None, state=None):
        params = {}
        if tag: params["tag"] = tag
        if state: params["state"] = state
        r = requests.get(f"{self.base}/work_items", params=params, timeout=10)
        r.raise_for_status()
        return r.json()

    def list_pipelines(self, name=None):
        params = {}
        if name: params["name"] = name
        r = requests.get(f"{self.base}/pipelines", params=params, timeout=10)
        r.raise_for_status()
        return r.json()

    def get_security_findings(self):
        r = requests.get(f"{self.base}/security_findings", timeout=10)
        r.raise_for_status()
        return r.json()

    def create_work_item(self, payload: dict):
        r = requests.post(f"{self.base}/work_items", json=payload, timeout=10)
        r.raise_for_status()
        return r.json()
