from pprint import pprint
from .tools import ADOClient
from .synthesizer import LLMClient

def run_demo(project="Phoenix"):
    client = ADOClient()
    llm = LLMClient()
    work_items = client.query_work_items(tag="release", state="Active")
    pipelines = client.list_pipelines(name="CI-main")
    security = client.get_security_findings()

    result = llm.summarize_readiness(work_items, pipelines, security)
    print("=== Release Readiness Result ===")
    pprint(result)

    if result["readiness_score"] < 50:
        payload = {
            "type": "Task",
            "title": f"Hotfix: Investigate release blockers for {project}",
            "state": "New",
            "priority": 1,
            "assignedTo": "oncall@example.com",
            "tags": ["hotfix","release"],
            "blocking": True
        }
        created = client.create_work_item(payload)
        print("\nCreated hotfix work item:")
        pprint(created)

if __name__ == "__main__":
    run_demo()
