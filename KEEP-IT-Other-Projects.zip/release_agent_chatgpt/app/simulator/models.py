from typing import List, Optional
from pydantic import BaseModel

class WorkItem(BaseModel):
    id: int
    type: str
    title: str
    state: str
    priority: int
    assignedTo: Optional[str]
    tags: List[str]
    blocking: bool = False
    acceptance_criteria: Optional[str] = None
    url: Optional[str] = None

class PipelineRun(BaseModel):
    run_id: int
    status: str
    time: str
    failed_stage: Optional[str]
    duration_seconds: Optional[int]

class Pipeline(BaseModel):
    pipeline_id: int
    name: str
    last_runs: List[PipelineRun]

class SecurityFinding(BaseModel):
    id: str
    component: str
    severity: str
    work_item: Optional[int]
    description: Optional[str]

class SecuritySummary(BaseModel):
    critical: int
    high: int
    medium: int
    details: List[SecurityFinding]
