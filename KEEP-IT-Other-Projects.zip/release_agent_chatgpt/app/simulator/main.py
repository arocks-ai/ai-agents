import json
from fastapi import FastAPI, HTTPException
from pathlib import Path
from typing import List
from .models import WorkItem, Pipeline, SecuritySummary

app = FastAPI(title="ADO Simulator")
BASE_DIR = Path(__file__).resolve().parent / "data"

def load_json(name):
    p = BASE_DIR / name
    with open(p, "r") as f:
        return json.load(f)

@app.get("/work_items", response_model=List[WorkItem])
def list_work_items(tag: str = None, state: str = None):
    items = load_json("work_items.json")
    def keep(it):
        if tag and tag not in it.get("tags", []):
            return False
        if state and it.get("state") != state:
            return False
        return True
    return [WorkItem(**it) for it in items if keep(it)]

@app.get("/work_items/{wi_id}", response_model=WorkItem)
def get_work_item(wi_id: int):
    items = load_json("work_items.json")
    for it in items:
        if it["id"] == wi_id:
            return WorkItem(**it)
    raise HTTPException(status_code=404, detail="Not found")

@app.get("/pipelines", response_model=List[Pipeline])
def list_pipelines(name: str = None):
    items = load_json("pipelines.json")
    if name:
        items = [p for p in items if name.lower() in p["name"].lower()]
    return [Pipeline(**p) for p in items]

@app.get("/pipelines/{pipeline_id}", response_model=Pipeline)
def get_pipeline(pipeline_id: int):
    items = load_json("pipelines.json")
    for p in items:
        if p["pipeline_id"] == pipeline_id:
            return Pipeline(**p)
    raise HTTPException(status_code=404, detail="Pipeline not found")

@app.get("/security_findings", response_model=SecuritySummary)
def get_security_summary():
    data = load_json("security_findings.json")
    return SecuritySummary(**data)

@app.post("/work_items", response_model=WorkItem)
def create_work_item(payload: dict):
    items = load_json("work_items.json")
    new_id = max(it["id"] for it in items) + 1
    payload["id"] = new_id
    payload.setdefault("state", "New")
    payload.setdefault("url", f"http://simulator/wi/{new_id}")
    return WorkItem(**payload)
