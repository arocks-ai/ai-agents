# Release Readiness Agent (Demo)

This repository contains a simulated Azure DevOps (ADO) connector and an agent that generates release readiness reports.

## Usage
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the demo:
   ```bash
   ./run_demo.sh
   ```
