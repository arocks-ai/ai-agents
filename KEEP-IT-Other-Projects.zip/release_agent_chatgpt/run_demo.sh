#!/usr/bin/env bash
uvicorn app.simulator.main:app --host 127.0.0.1 --port 8000 --reload &
SIM_PID=$!
sleep 1
python -m app.agent.main
kill $SIM_PID || true